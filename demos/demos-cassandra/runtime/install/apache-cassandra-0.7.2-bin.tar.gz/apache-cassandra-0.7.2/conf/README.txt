Required configuration files
============================

cassandra.yaml: main Cassandra configuration file
log4j-server.proprties: log4j configuration file for Cassandra server


Optional configuration files
============================

access.properties: used for authorization
passwd.properties: used for authentication
cassandra-topology.properties: used by PropertyFileSnitch
